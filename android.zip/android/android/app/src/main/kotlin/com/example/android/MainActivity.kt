package com.example.android

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
